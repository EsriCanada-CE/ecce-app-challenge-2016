// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/BoxTheme/nls/strings":{_themeLabel:"Th\u00e8me encart",_layout_default:"Mise en page par d\u00e9faut",_layout_top:"Mise en page sup\u00e9rieure",_localized:{}}});