# accessMTL
This App is founded on basis of Universal Accessiblity Principles and other socially sustainable practices/principles
