﻿define(
   ({
    _widgetLabel: "坐标",
    hintMessage: "单击地图以获取坐标",
    defaultLabel: "默认值",
    realtimeLabel: "移动鼠标以获取坐标",
    computing: "正在计算...",
    latitudeLabel: "纬度",
    longitudeLabel: "经度",
    loading: "正在加载...",
    enableClick: "单击启用单击地图以获取坐标",
    disableClick: "单击禁用单击地图以获取坐标",

    Default: "默认值",
    Inches: "英寸",
    Foot: "英尺",
    Yards: "码",
    Miles: "英里",
    Nautical_Miles: "海里",
    Millimeters: "毫米",
    Centimeters: "厘米",
    Meter: "米",
    Kilometers: "千米",
    Decimeters: "分米",
    Decimal_Degrees: "度",
    Degree_Minutes_Seconds: "度分秒",
    MGRS: "MGRS",
    USNG: "USNG"
  })
);
