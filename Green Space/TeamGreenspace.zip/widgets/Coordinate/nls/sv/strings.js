﻿define(
   ({
    _widgetLabel: "Koordinat",
    hintMessage: "Klicka på kartan för att hämta koordinater",
    defaultLabel: "Standard",
    realtimeLabel: "Flytta musen för att hämta koordinater",
    computing: "Beräknar ...",
    latitudeLabel: "Latitud",
    longitudeLabel: "Longitud",
    loading: "läser in...",
    enableClick: "Klicka om du vill aktivera att få koordinater genom att klicka på kartan",
    disableClick: "Klicka om du vill inaktivera att få koordinater genom att klicka på kartan",

    Default: "Standard",
    Inches: "Tum",
    Foot: "Fot",
    Yards: "Yard",
    Miles: "Engelska mil",
    Nautical_Miles: "Nautiska mil",
    Millimeters: "Millimeter",
    Centimeters: "Centimeter",
    Meter: "Meter",
    Kilometers: "Kilometer",
    Decimeters: "Decimeter",
    Decimal_Degrees: "Grader",
    Degree_Minutes_Seconds: "Grader minuter sekunder",
    MGRS: "MGRS",
    USNG: "USNG"
  })
);
