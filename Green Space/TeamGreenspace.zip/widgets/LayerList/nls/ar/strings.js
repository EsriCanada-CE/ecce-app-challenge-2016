﻿define(
   ({
    _widgetLabel: "قائمة الطبقات",
    titleBasemap: "خرائط الأساس",
    titleLayers: "الطبقات التشغيلية",
    labelLayer: "اسم الطبقة",
    itemZoomTo: "تكبير إلى",
    itemTransparency: "معدل الشفافية:",
    itemTransparent: "شفاف",
    itemOpaque: "غير شفاف",
    itemMoveUp: "نقل لأعلى",
    itemMoveDown: "نقل لأسفل",
    itemDesc: "الوصف",
    itemDownload: "تنزيل",
    itemToAttributeTable: "فتح جدول البيانات الجدولية",
    itemShowItemDetails: "إظهار تفاصيل العنصر",
    empty: "فارغ",
    removePopup: "تعطيل النافذة المنبثقة",
    enablePopup: "تمكين العنصر المنبثق"
  })
);
