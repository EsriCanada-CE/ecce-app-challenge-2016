﻿define(
   ({
    _widgetLabel: "Seznam vrstev",
    titleBasemap: "Podkladové mapy",
    titleLayers: "Operační vrstvy",
    labelLayer: "Název vrstvy",
    itemZoomTo: "Přiblížit na",
    itemTransparency: "Průhlednost",
    itemTransparent: "Průhledná",
    itemOpaque: "Neprůhledná",
    itemMoveUp: "Přesunout nahoru",
    itemMoveDown: "Přesunout dolů",
    itemDesc: "Popis",
    itemDownload: "Stáhnout",
    itemToAttributeTable: "Otevřít atributovou tabulku",
    itemShowItemDetails: "Ukázat podrobnosti položky",
    empty: "prázdné",
    removePopup: "Zakázat vyskakovací okna",
    enablePopup: "Povolit vyskakovací okno"
  })
);
