﻿define(
   ({
    _themeLabel: "Šautras dizains",
    _layout_default: "Noklusējuma izkārtojums"
  })
);
