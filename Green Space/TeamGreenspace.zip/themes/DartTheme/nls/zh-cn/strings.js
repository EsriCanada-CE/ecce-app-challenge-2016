﻿define(
   ({
    _themeLabel: "镖主题",
    _layout_default: "默认布局"
  })
);
