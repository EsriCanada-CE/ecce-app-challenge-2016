﻿define(
   ({
    _themeLabel: "鏢主題",
    _layout_default: "預設版面配置"
  })
);
