﻿define(
   ({
    _themeLabel: "Motyw Rzutka",
    _layout_default: "Układ domyślny"
  })
);
