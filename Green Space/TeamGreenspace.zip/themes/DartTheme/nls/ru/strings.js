﻿define(
   ({
    _themeLabel: "Тема дротика",
    _layout_default: "Компоновка по умолчанию"
  })
);
