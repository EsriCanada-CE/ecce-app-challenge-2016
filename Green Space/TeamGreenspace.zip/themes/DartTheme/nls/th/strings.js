﻿define(
   ({
    _themeLabel: "ดาร์ทธีม",
    _layout_default: "โครงร่างตั้งต้น"
  })
);
