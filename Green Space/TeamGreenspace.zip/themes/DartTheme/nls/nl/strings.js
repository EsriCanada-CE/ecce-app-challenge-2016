﻿define(
   ({
    _themeLabel: "Dartthema",
    _layout_default: "Standaard lay-out"
  })
);
