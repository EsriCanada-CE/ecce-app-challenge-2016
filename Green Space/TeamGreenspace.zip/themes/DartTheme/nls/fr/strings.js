﻿define(
   ({
    _themeLabel: "Thème Fléchette",
    _layout_default: "Mise en page par défaut"
  })
);
