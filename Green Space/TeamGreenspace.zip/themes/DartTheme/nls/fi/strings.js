﻿define(
   ({
    _themeLabel: "Nuoliteema",
    _layout_default: "Oletusasettelu"
  })
);
