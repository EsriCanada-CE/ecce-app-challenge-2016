﻿define(
   ({
    _themeLabel: "Teema Dart",
    _layout_default: "Vaikimisi paigutus"
  })
);
