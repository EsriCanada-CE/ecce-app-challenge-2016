﻿define(
   ({
    _themeLabel: "ダート テーマ",
    _layout_default: "デフォルトのレイアウト"
  })
);
