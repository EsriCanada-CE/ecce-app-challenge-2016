﻿define(
   ({
    _themeLabel: "נושא חץ",
    _layout_default: "פריסת ברירת מחדל"
  })
);
