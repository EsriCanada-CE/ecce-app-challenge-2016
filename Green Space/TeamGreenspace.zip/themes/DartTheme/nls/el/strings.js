﻿define(
   ({
    _themeLabel: "Θέμα Dart",
    _layout_default: "Προκαθορισμένη διάταξη"
  })
);
