﻿define(
   ({
    _themeLabel: "Motiv šipek",
    _layout_default: "Výchozí rozvržení"
  })
);
