﻿define(
   ({
    _widgetLabel: "Ovladač šipek"
  })
);
