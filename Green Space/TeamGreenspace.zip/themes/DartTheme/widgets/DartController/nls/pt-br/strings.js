﻿define(
   ({
    _widgetLabel: "Controlador de Lançamento"
  })
);
