﻿define(
   ({
    _widgetLabel: "Smiginio valdiklis"
  })
);
