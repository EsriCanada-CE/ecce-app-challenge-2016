﻿define(
   ({
    _widgetLabel: "镖控制器"
  })
);
