﻿define(
   ({
    _widgetLabel: "Pilhanteraren"
  })
);
