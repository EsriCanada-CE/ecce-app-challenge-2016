﻿define(
   ({
    _widgetLabel: "Контроллер дротика"
  })
);
