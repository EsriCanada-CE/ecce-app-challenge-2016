﻿define(
   ({
    _widgetLabel: "בקר חץ"
  })
);
