﻿define(
   ({
    _widgetLabel: "鏢控制器"
  })
);
