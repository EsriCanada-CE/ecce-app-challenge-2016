﻿define(
   ({
    _widgetLabel: "Controlador Dardo"
  })
);
