﻿define(
   ({
    _widgetLabel: "Controller Freccetta"
  })
);
