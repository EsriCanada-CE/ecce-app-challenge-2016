﻿define(
   ({
    _widgetLabel: "مُتحكم الانطلاق"
  })
);
