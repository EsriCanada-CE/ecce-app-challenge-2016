﻿define(
   ({
    _widgetLabel: "Dart-Controller"
  })
);
