﻿define(
   ({
    _widgetLabel: "Dart kontroller"
  })
);
