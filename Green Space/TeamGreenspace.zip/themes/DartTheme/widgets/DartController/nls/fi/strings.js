﻿define(
   ({
    _widgetLabel: "Nuolisäädin"
  })
);
