// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"Rotaslietu k\u0101rbi\u0146as dizains",_layout_default:"Noklus\u0113juma izk\u0101rtojums",_layout_layout1:"1. izk\u0101rtojums",emptyDocablePanelTip:"Logr\u012bka ciln\u0113 noklik\u0161\u0137iniet uz pogas\u00a0\u201c+\u201d, lai pievienotu logr\u012bku. ",_localized:{}}});