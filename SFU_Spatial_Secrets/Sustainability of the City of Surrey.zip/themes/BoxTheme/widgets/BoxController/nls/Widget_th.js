// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/BoxTheme/widgets/BoxController/nls/strings":{_widgetLabel:"\u0e01\u0e25\u0e48\u0e2d\u0e07\u0e04\u0e27\u0e1a\u0e04\u0e38\u0e21",_localized:{}}});