// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/BoxTheme/widgets/BoxController/nls/strings":{_widgetLabel:'\u041a\u043e\u043d\u0442\u0440\u043e\u043b\u043b\u0435\u0440 \u0442\u0435\u043c\u044b "\u043a\u043e\u0440\u043e\u0431\u043a\u0430"',_localized:{}}});