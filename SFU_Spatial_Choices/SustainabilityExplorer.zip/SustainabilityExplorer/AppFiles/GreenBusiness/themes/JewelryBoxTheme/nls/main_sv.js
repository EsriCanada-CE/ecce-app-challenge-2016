// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"Tema f\u00f6r smyckeskrin",_layout_default:"Standardlayout",_layout_layout1:"Layout 1",emptyDocablePanelTip:"Klicka p\u00e5 plusknappen (+) p\u00e5 fliken Widget om du vill l\u00e4gga till en widget. ",_localized:{}}});