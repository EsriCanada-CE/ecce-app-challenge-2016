// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"M\u00fccevher Kutusu Temas\u0131",_layout_default:"Varsay\u0131lan D\u00fczen",_layout_layout1:"D\u00fczen 1",emptyDocablePanelTip:"Ara\u00e7 eklemek i\u00e7in Ara\u00e7 sekmesinde + d\u00fc\u011fmesine t\u0131klay\u0131n. ",_localized:{}}});